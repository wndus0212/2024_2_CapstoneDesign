import yfinance as yf
import sqlite3
import os


def init_db(db_path):
    """
    데이터베이스 초기화 및 테이블 생성.
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS stock_history (
            ticker TEXT NOT NULL,
            date DATE NOT NULL,
            open REAL,
            high REAL,
            low REAL,
            close REAL,
            volume INTEGER,
            PRIMARY KEY (ticker, date)
        )
    ''')
    conn.commit()
    return conn


def get_and_save_financial_data_to_db(stock_id, conn):
    """
    yfinance에서 데이터를 가져와 데이터베이스에 저장.
    """
    stock = yf.Ticker(stock_id)
    stock_history = stock.history(interval='1d', period='max', auto_adjust=False)

    # 필요한 열만 선택
    stock_history = stock_history[['Open', 'High', 'Low', 'Close', 'Volume']]

    # 인덱스를 날짜(Date) 열로 변환하고, YYYY-MM-DD 형식으로 변환
    stock_history.reset_index(inplace=True)
    stock_history['Date'] = stock_history['Date'].dt.date  # 날짜만 남기기 (YYYY-MM-DD)

    # 열 이름 변경
    stock_history.rename(columns={
        'Date': 'date',
        'Open': 'open',
        'High': 'high',
        'Low': 'low',
        'Close': 'close',
        'Volume': 'volume'
    }, inplace=True)

    # 데이터베이스에 저장
    cursor = conn.cursor()
    for _, row in stock_history.iterrows():
        cursor.execute('''
            INSERT OR IGNORE INTO stock_history (ticker, date, open, high, low, close, volume)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (stock_id, row['date'], row['open'], row['high'], row['low'], row['close'], row['volume']))
    conn.commit()

    print(f"Data for {stock_id} saved to database")


# 데이터베이스 경로 설정
db_path = r'C:\Users\shs\Desktop\code\login\1\databse.sqlite3'

# 데이터베이스 초기화
conn = init_db(db_path)

# 원하는 종목 리스트
stock_ids = ['AAPL', 'TSLA', 'JPM', 'AMZN', 'MSFT', '005930.KS', '105560.KS', '196170.KQ', '247540.KQ']

# 각 종목 데이터를 가져와 데이터베이스에 저장
for stock_id in stock_ids:
    get_and_save_financial_data_to_db(stock_id, conn)

# 데이터베이스 연결 닫기
conn.close()
